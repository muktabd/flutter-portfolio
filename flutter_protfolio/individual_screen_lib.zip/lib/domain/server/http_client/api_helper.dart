
import 'package:get/get.dart';
import 'request_handler.dart';

abstract class ApiHelper{
  final requestHandler = Get.find<RequestHandler>();
}