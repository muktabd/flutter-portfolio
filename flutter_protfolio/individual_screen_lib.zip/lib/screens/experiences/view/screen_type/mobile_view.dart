/*
Hello there!👋
This is me Abdullah Ibna Mukta, You can call me Mukta. I am a full stack developer. Started my journey with mobile application development but now
prepared myself for all kind of platforms Android, iOS, Web, Desktop and even IoT. I am a quick learner and a fast developer. 

*/